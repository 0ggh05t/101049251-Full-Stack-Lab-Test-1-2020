//Question 1: ES6 Features

const lowerCaseWords = ['PIZZA', 10, true, 25, false, 'Wings']

console.log('pizza','wings');